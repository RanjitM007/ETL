import boto3
from botocore import client
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType


def config_aws_s3_creds(
    spark_session: SparkSession,
    aws_key: str = '',
    aws_secret: str = '',
) -> None:
    """Config spark session with AWS credentials

    Args:
        spark_session (SparkSession): Spark Session of the cluster
        aws_key (str, optional): AWS User Access Key.
        aws_secret (str, optional): AWS User Secret Key.
    """
    spark_session._jsc.hadoopConfiguration().set("fs.s3n.awsAccessKeyId", aws_key)
    spark_session._jsc.hadoopConfiguration().set(
        "fs.s3n.awsSecretAccessKey", aws_secret
    )
    spark_session._jsc.hadoopConfiguration().set("fs.s3n.endpoint", "s3.amazonaws.com")

    return


def create_s3_client(
    access_key_id: str, secret_access_key: str, session_token: str
) -> client:
    """Creates a AWS to access S3 programmatically

    Args:
        access_key_id (str): AWS User Access Key
        secret_access_key (str): AWS User Secret Key
        session_token (str): AWS User Session Token

    Returns:
        client: Client.S3 object to be use in other functions
    """
    return boto3.client(
        service_name="s3",
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
    )
