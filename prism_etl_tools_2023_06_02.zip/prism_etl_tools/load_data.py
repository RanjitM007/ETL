from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
import boto3


def df_to_delta_table(
    spark_session: SparkSession,
    df: DataFrame,
    schema: str,
    table_name: str,
    mode: str = "overwrite",
    new_schema: bool = False,
) -> None:
    """Write a df as a delta table in the defined schema (can create one if it doesn't exists.

    Args:
        df (DataFrame): Dataframe to be written as a delta table
        schema (str): Schema where the data table will be written
        table_name (str): Name of the table to be written
        mode (str, optional): Flag to define if table should be appended ('append') or overwritten ('overwrite'). Defaults to overwrite
        new_schema (bool, optional): Flag to define if the schema should be created. Defaults to False

    Returns:
        None: Function has no return value
    """
    if new_schema == False:
        df.write.option("mergeSchema", "true").format("delta").mode(mode).saveAsTable(
        f"{schema}.{table_name}")    
    else:
        print("Schema not created.")
    
    return None


def df_to_s3_csv(
    df: DataFrame,
    bucket: str,
    path: str,
    mode: str = "overwrite",
    sep: str = ",",
    header: str = "true",
    emptyValue: str = "",
    **kwargs,
) -> None:
    """Write a df as a .csv file in the defined AWS S3 Bucket and Path.

    Args:
        df (DataFrame): Dataframe to be writen as a delta table
        mode (str, optional): Flag to define if table should be appended ('append') or overwritten ('overwrite'). Defalts to overwrite
        bucket (str): Bucket name to be read from in S3
        path (str): Path to file, inside bucket
        sep (list, optional): Sets a separator for each field and value. Defalts to ','
        header (str, optional): For reading, uses the first line as names of columns. Defalts to 'true'
        emptyValue (str, optional): writes '' values as NULL
        kwarg (Any): Any other options (key, value pair) from the spark.read.csv function. Format to be used 'key'='value'

    Returns:
        None: Function has no return value
    """
    df.write.options(sep=sep, header=header, emptyValue=emptyValue, **kwargs).mode(
        mode
    ).csv(f"s3://{bucket}/{path}")

    return None


def df_to_s3_single_csv_file(
    df: DataFrame,
    bucket: str,
    path: str,
    mode: str = "overwrite",
    sep: str = ",",
    header: str = "true",
    emptyValue: str = "",
    lib: str = "pandas",
    aws_key: str = '',
    aws_secret: str = '',
    adjust_max_timestamp: bool = False,
    date_end_col_name: str = 'dte_eff_end',
    **kwargs,
) -> None:
    """Write a df as a single .csv file in the defined AWS S3 Bucket and Path. This do note create metadata files.

    Args:
        df (DataFrame): Dataframe to be writen as a delta table
        mode (str, optional): Flag to define if table should be appended ('append') or overwritten ('overwrite'). Defalts to overwrite
        bucket (str): Bucket name to be read from in S3
        path (str): Path to file, inside bucket
        sep (list, optional): Sets a separator for each field and value. Defalts to ','
        header (str, optional): For reading, uses the first line as names of columns. Defalts to 'true'
        emptyValue (str, optional): writes '' values as NULL
        lib (str, optional): Selects the library to be used to read the DataFrame. Set to 'pandas' or 'pyspark'. Defaults to 'pandas'
        aws_key (str): Sets the AWS Access Key to be used to upload data to S3. Defaults to ''.
        aws_secret (str): Sets the AWS Secret Access Key to be used to upload data to S3. Defaults to ''.
        adjust_max_timestamp (bool, optional): Defines, if True, that the selected max timestamp column is adjusted so that the DataFrame can be ingested in pandas. Defaults to False.
        date_end_col_name (str, optional): Sets the name of the max Timestamp function to be adjusted when using the 'pandas' selection in the lib argument.
        kwargs (Any): Any other options (key, value pair) from the spark.read.csv function. Format to be used 'key'='value'

    Returns:
        None: Function has no return value
    """

    if lib == "pandas":

        import pandas as pd
        from io import StringIO

        if adjust_max_timestamp:
            if date_end_col_name in df.columns:
                df = df.withColumn(date_end_col_name, F.lit(None))

        s3_client = boto3.client(
            "s3", aws_access_key_id=aws_key, aws_secret_access_key=aws_secret, **kwargs
        )
        session = boto3.Session(
            aws_access_key_id=aws_key, aws_secret_access_key=aws_secret, **kwargs
        )

        s3 = session.resource("s3")
        try:
            df_pd = df.toPandas()
            if adjust_max_timestamp:
                df_pd[date_end_col_name] = pd.Timestamp.max
            
        except:
            df_pd = pd.DataFrame(columns=df.columns)
            
        csv_buffer = StringIO()
        df_pd.to_csv(csv_buffer, index=False)
        s3.Object(bucket, path).put(Body=csv_buffer.getvalue())

        return None


def update_and_load_abc_entry(
    spark_session: SparkSession, 
    df_abc_job_run_dtl: DataFrame, 
    prefix: str,
    schema: str = "nps_prism_silver_layer"
    ) -> None:

    """Update both abc_job_dtl and abc_job_run_dtl tables with created DataFrames

    Args:
        - spark_session (SparkSession): Spark Session name of the cluster
        - df_abc_job_run_dtl (DataFrame): Dataframe of the abc_job_run_dtl record to be updated
        - prefix (str): Prefix of the instrument that is being updated. Ex. ("br_auto")
        - schema (str): Schema for the abc_job_run table to be saved

    Returns:
        None: Function has no return value
    """

    df_to_delta_table(
        spark_session,
        df_abc_job_run_dtl,
        schema,
        f"{prefix}_abc_job_run_dtl",
        "append",
    )

    return None


def save_df_to_debug_layer(df: DataFrame, table_name: str) -> None:
    """Save Data Frame to debug layer with specific name.

    Args:
        df (DataFrame): Data frame to be saved
        table_name (str): Name to be used as table name in the debug layer

    Returns:
        This function has no return
    """
    df.write.option("overwriteSchema", "true").format("delta").mode(
        "overwrite"
    ).saveAsTable(f"nps_prism_debug_layer.{table_name}")

    return None
