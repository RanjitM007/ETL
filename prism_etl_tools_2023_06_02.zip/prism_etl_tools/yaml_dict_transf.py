from prism_etl_tools.env_config import *
from prism_etl_tools.ingest_data import *
from prism_etl_tools.load_data import *
from prism_etl_tools.transform_data import *
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession

# from pyspark.sql.dataframe import DataFrame
from botocore import client


def s3_yaml_to_dict(aws_s3_client: client, s3_bucket: str, yaml_file_path: str) -> dict:
    """Read a .yaml file from AWS S3 Bucket and returns a python dictionary with its content.

    Args:
        aws_s3_client (client): AWS S3 client object, created with the function 'create_s3_client'
        s3_bucket (str): Name of the S3 bucket containing the file
        yaml_file_path (str): Complete path to the file inside the bucket, including the file name with '.yaml' suffix

    Returns:
        dict: Python Dictionary created using the body of the Yaml file
    """
    import yaml

    response = aws_s3_client.get_object(Bucket=s3_bucket, Key=yaml_file_path)

    try:
        yaml_dict = yaml.safe_load(response["Body"])
    except yaml.YAMLError as exc:
        print(exc)
    return yaml_dict


def check_func_args_for_dataframes_or_functions(arg_dict: dict, df_dict: dict) -> dict:
    """Check the dictionary values to change string entries of Data Frames and Pyspark Function into actual Data Frames and Functions.

    Args:
        arg_dict (dict): Argument Dictionary created by reading the yaml file
        df_dict (dict): Data Frame dictionary used in the job creation

    Returns:
        dict: Corrected version of the Argument Dictionary
    """
    for k, v in arg_dict.items():
        if type(v) != str:
            continue
        elif v.startswith("dataframe->"):
            df_name = v.split("->")[-1]
            arg_dict[k] = df_dict[df_name]
        elif v.startswith(("F.", "[", "{", "T.", "~", "df_dict", "spark")):
            arg_dict[k] = eval(v)
        elif v.startswith(("on->")):
            arg_dict[k] = eval(v.split("on->")[-1])
    return arg_dict


def run_yaml_pipeline(
    arg_dict: dict,
    spark_session: SparkSession,
    bucket: str,
    yaml_path: str,
    write_layer: bool = True,
    whole_table_to_csv: bool = True,
    aws_access_key:str = '',
    aws_secret_access_key:str = ''
) -> dict:
    """Runs a .yaml file from AWS S3 Bucket and returns a dictionary with the final DataFrames, also saving them as CSVs to S3, of the user chosses to do so.

    Args:
        arg_dict (dict): Dictionary with the arguments to be used by the function.
        spark_session (SparkSession): Spark Session of the cluster.
        bucket (str): S3 bucket where the yaml file is stored.
        yaml_path (str): Complete path to the file inside the bucket, including the file name with '.yaml' suffix.
        write_layer (bool): Layer for the resulting tables to be saved. Defaults to True.
        whole_table_to_csv (bool): Parameter to indicate if the entire table should be saved o S3 as a csv file. Defaults to True.
        aws_access_key (str): AWS access key to be used to access S3. Defaults to ''.
        aws_secret_access_key (str): AWS secret access key to be used to access S3. Defaults to ''.

    Returns:
        dict: Python Dictionary containing all created PySpark DataFrames, with csv equivalents saved to S3, if selected.
    """   

    final_dfs = {}
    for task_name, task_dict in arg_dict.items():
        print(f"Starting task: {task_name}")
        df_dict = {}

        # Source Ingestions
        for source, source_args in task_dict["sources"].items():
            schema = source_args["schema"]
            name = source_args["name"]
            alias = source_args["alias"]
            df_dict[alias] = delta_table_to_df(spark_session, schema, name)

        # Transformations
        for transform, transform_args in task_dict["transforms"].items():
            if transform_args["type"] == "prism_lib":

                if "spark_session" in transform_args['argument'].keys():
                    transform_args['argument']['spark_session'] = spark_session
                else:
                    pass

                arg_dict = check_func_args_for_dataframes_or_functions(
                    transform_args["argument"], df_dict
                )
                df_dict[transform_args["alias"]] = eval(transform_args["name"])(
                    **arg_dict
                )
            elif transform_args["type"] == "core_pyspark_sql_functions":
                df_name = transform_args["argument"]["base_df_alias"]
                df_base = df_dict[df_name]

                del transform_args["argument"]["base_df_alias"]
                arg_dict = check_func_args_for_dataframes_or_functions(
                    transform_args["argument"], df_dict
                )
                if (
                    (transform_args["name"] == "select") and (type(arg_dict["cols"]) == list)
                ):  # Create a custom select function to remove this part
                    df_dict[transform_args["alias"]] = df_base.select([*arg_dict["cols"]])
                else:
                    df = getattr(df_base, transform_args["name"])
                    df_dict[transform_args["alias"]] = df(**arg_dict)

        # Write Table
        write_dict = task_dict["write"]
        df_to_write = df_dict[write_dict["alias_name"]]
        final_schema = write_dict["final_schema"]
        final_table_name = write_dict["final_name"]
        write_mode = write_dict["write_mode"]

        df_to_delta_table(
            spark_session, df_to_write, final_schema, final_table_name, write_mode
        )

        if write_layer and whole_table_to_csv:

            corr_path = yaml_path.split("/")[:-2]
            complete_corr_path = (
                "/".join(corr_path)
                + "/s3_postgresql_gateway_files/"
                + final_table_name
                + ".csv"
            )
            whole_df = delta_table_to_df(spark_session, final_schema, final_table_name)
            df_to_s3_single_csv_file(whole_df, bucket, complete_corr_path, aws_key=aws_access_key, aws_secret=aws_secret_access_key)

        elif write_layer and not whole_table_to_csv:
            corr_path = yaml_path.split("/")[:-2]
            complete_corr_path = (
                "/".join(corr_path)
                + "/s3_postgresql_gateway_files/"
                + final_table_name
                + ".csv"
            )
            df_to_s3_single_csv_file(df_to_write, bucket, complete_corr_path, aws_key=aws_access_key, aws_secret=aws_secret_access_key)

        final_dfs[task_name] = df_dict
        print(f"Concluded the task: {task_name}")

    return final_dfs


def run_yaml_pipeline_debug(
    arg_dict: dict,
    spark_session,
    bucket: str,
    yaml_path: str,
    display_dfs: bool = True,
    display_specific_alias: list = []
) -> dict:
    final_dfs = {}
    
    if len(display_specific_alias) > 0:
        display_dfs = False
    
    for task_name, task_dict in arg_dict.items():
        print(f"Starting task: {task_name}")
        df_dict = {}

        # Source Ingestions
        for source, source_args in task_dict["sources"].items():
            schema = source_args["schema"]
            name = source_args["name"]
            alias = source_args["alias"]
            df_dict[alias] = delta_table_to_df(spark_session, schema, name)

        # Transformations
        for transform, transform_args in task_dict["transforms"].items():
            print("_____________ TRANSFORMS ______________")
            print(transform, transform_args)
            
            if transform_args["type"] == "prism_lib":
                
                if "spark_session" in transform_args['argument'].keys():
                    transform_args['argument']['spark_session'] = spark_session
                else:
                    pass
                
                arg_dict = check_func_args_for_dataframes_or_functions(
                    transform_args["argument"], df_dict
                )
                df_dict[transform_args["alias"]] = eval(transform_args["name"])(
                    **arg_dict
                )
                
            elif transform_args["type"] == "core_pyspark_sql_functions":
                df_name = transform_args["argument"]["base_df_alias"]
                df_base = df_dict[df_name]

                del transform_args["argument"]["base_df_alias"]
                arg_dict = check_func_args_for_dataframes_or_functions(
                    transform_args["argument"], df_dict
                )
                if (
                    (transform_args["name"] == "select") and (type(arg_dict["cols"]) == list)
                ):  # Create a custom select function to remove this part
                    df_dict[transform_args["alias"]] = df_base.select([*arg_dict["cols"]])
                else:
                    df = getattr(df_base, transform_args["name"])
                    df_dict[transform_args["alias"]] = df(**arg_dict)


            if (display_dfs) or (transform_args["alias"] in display_specific_alias):
                df_dict[alias].display()
                            
        final_dfs[task_name] = df_dict
        print(f"Concluded the task: {task_name}")

    return final_dfs