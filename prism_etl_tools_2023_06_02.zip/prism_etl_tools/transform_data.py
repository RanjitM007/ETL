import re
from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql.dataframe import DataFrame
from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, StringType
from prism_etl_tools.load_data import (
    df_to_s3_single_csv_file,
    df_to_delta_table,
    update_and_load_abc_entry,
)
from prism_etl_tools.ingest_data import delta_table_to_df

from typing import Union, Any


def md5_hash(string_to_hash: str, encode: str = "utf-8") -> str:
    """Create a hash from string, with chosen encode, using the MD5 algorithm.

    Args:
        string_to_hash (str): String to be used as base of the hash code.
        encode (str, optional): Encoding to be used with the string. Defaults to 'utf-8'.

    Returns:
        str: Hashed string
    """
    from hashlib import md5

    return md5(string_to_hash.encode(encode)).hexdigest()


def create_hash_col(
    df: DataFrame, col_list: list, hash_col_name: str, encode: str = "utf-8"
) -> DataFrame:
    """Create a hash column from list of columns, with chosen encode, using the MD5 algorithm.

    Args:
        df (DataFrame): Data frame where the column will be created and from where the string to hash will be concatenated
        col_list (list): Columns to be appended and used as base to create the hash key
        hash_col_name (str): Name of the column with the hash_key. Cannot be "hash_str"
        encode (str, optional): Encoding to be used with the string. Defaults to 'utf-8'.

    Returns:
        DataFrame: DataFrame with hash_key column
    """
    udf_md5_hash = F.udf(md5_hash, T.StringType())
    df = (
        df.withColumn("hash_str", F.concat_ws("", *col_list))
        .withColumn("hash_str", F.lower("hash_str"))
        .withColumn("hash_str", F.regexp_replace("hash_str", " ", ""))
    )

    df = df.withColumn(hash_col_name, udf_md5_hash(F.col("hash_str"), F.lit(encode)))
    df = df.drop("hash_str")

    return df


def trim_str_columns(df: DataFrame) -> DataFrame:
    """Select all the columns that contain string (object) data types and trim the values

    Args:
        df (DataFrame): Data frame to be trimmed

    Returns:
        DataFrame: The whole data frame with the str columns trimmed
    """
    column_list = [item[0] for item in df.dtypes if item[1].startswith("string")]
    for c_name in column_list:
        df = df.withColumn(c_name, F.trim(F.col(c_name)))

    return df


def clean_duplicate_entries(
    col_list: list, df_new: DataFrame, df_old: DataFrame = None
) -> DataFrame:
    """Checks the rows in the new data frame that doesn't exist in the old one, based in a set of columns.

    Args:
        col_list (list): List of column names to be used in the comparison between data frames
        df_new (DataFrame): Data frame to be cleaned
        df_old (DataFrame): Data frame with entries to be removed from the new one

    Returns:
        Spark.DataFrame: The new data frame without the rows present in the old data frame.
    """
    if df_old == None:
        df_new = df_new.dropDuplicates()

        return df_new

    else:
        df_old = df_old.withColumn("compare_str", F.concat_ws("", *col_list))
        df_old = df_old.withColumn("compare_str", F.lower("compare_str")).withColumn(
            "compare_str", F.regexp_replace("compare_str", " ", "")
        )

        df_new = df_new.withColumn("compare_str", F.concat_ws("", *col_list))
        df_new = df_new.withColumn("compare_str", F.lower("compare_str")).withColumn(
            "compare_str", F.regexp_replace("compare_str", " ", "")
        )

        df_clean = df_new.join(df_old, on="compare_str", how="leftanti").drop(
            "compare_str"
        )

        return df_clean


def create_gid_table_column(
    spark_session: SparkSession,
    df: DataFrame,
    gid_suffix: str,
    schema: str,
    df_old_name: str = None,
) -> DataFrame:
    """Creates the gid column for the table, starting with 1 if there are no prior entries or continuing the gid count in case it exists.
        Also, cleans the data frame to contain only new entries, applying the 'clean_duplicate_entries' function.
    Args:
        spark_session (SparkSession): Spark Session of the cluster
        df (DataFrame): DataFrame where the column should be constructed
        gid_suffix (str): Suffix to be used in the column name. Normally it is the table name
        schema (str): Schema where the prior table (df_old) is located
        cols_to_compare (list, optional): List of column names to be used in the comparison between the new table and the existing one. Default value is empty list.
        df_old_name (str, optional): Name of the existing table to be compared with. Defaults to None.
    Returns:
        DataFrame: Cleaned DataFrame with the gid column created
    """
    gid_col = "gid_" + gid_suffix

    try:
        df_old = delta_table_to_df(spark_session, schema, df_old_name)
        max_gid = df_old.groupBy().max(gid_col).first().asDict()[f"max({gid_col})"]
    except:
        max_gid = 0

    from pyspark.sql.window import Window as W

    df_final = df.withColumn("idx", F.monotonically_increasing_id())
    windowSpec = W.orderBy("idx")
    df_final = df_final.withColumn(gid_col, F.row_number().over(windowSpec))
    df_final = df_final.withColumn(gid_col, F.col(gid_col) + max_gid)
    df_final = df_final.drop("idx")

    return df_final


def clean_snakecase_col_names(df: DataFrame) -> DataFrame:
    """Format the column names of a dataframe to snakecase (lower and separated by underscores)

    Args:
        df (DataFrame): Data frame from with the columns will be formated

    Returns:
        DataFrame: Dataframe with column names formated to snakecase
    """
    for name in df.columns:
        clean_name = re.sub(r"[\s\.]+", "_", name)
        df = df.withColumnRenamed(name, clean_name.lower())

    return df


def rename_multiple_columns(df: DataFrame, nam_dict: dict) -> DataFrame:
    """Change the name of different columns, based on a dictionary

    Args:
        df (DataFrame): Data frame witch columns will be renamed
        name_dict (dict): Python dictionary (key, value pair) with keys being the old column name and the values the new names

    Returns:
        DataFrame: Dataframe with columns renamed
    """
    for key, value in nam_dict.items():
        df = df.withColumnRenamed(key, value)

    return df


def create_null_columns(
    df: DataFrame,
    col_names: list,
    to_type: bool = True,
    spark_type: str = "T.StringType()",
) -> DataFrame:
    """Create null columns in the dataframe, based on a list of column names.

    Args:
        df (DataFrame): Data frame where the columns will be created
        col_names (list): Python list with names for the null columns to be created
        to_type (bool, optional): Flag to select if nulls should be cast as defined type. Defaults to True.

    Returns:
        DataFrame: Dataframe with null columns created
    """
    col_names_new = [item for item in col_names if item not in df.columns]

    if to_type:
        for col in col_names_new:
            df = df.withColumn(col, F.lit(None).cast(eval(spark_type)))
    else:
        for col in col_names_new:
            df = df.withColumn(col, F.lit(None))

    return df


def get_job_instrument_names(
    geo_tag: str, industry: str, job: str = None
) -> Union[str, str]:
    """Define the job/task name and the standard instrument name.

    Args:
        geo_tag (str): Name or letter tag representing the geo location of the instrument
        industry (str): Name of the industry adressed in the instrument
        job (str, optional): Name job/task to be registred in the ABC table. If None is passed as argument, it returns the notebook name. Defaults to None.

    Returns:
        str: Job name in lower case
        str: Instrument name with the geo tag in upper case and the industry name in title case, separated by a dash (-)
    """
    if job == None:
        notebook_path = (
            dbutils.notebook.entry_point.getDbutils()
            .notebook()
            .getContext()
            .notebookPath()
            .get()
        )
        job_name = notebook_path.split("/")[-1]
    else:
        job_name = job

    instrument = geo_tag.upper() + "-" + industry.title()

    return job_name.lower(), instrument


def melt_table_drop_cols(
    df: DataFrame, id_vars: list, value_vars: list = [], cols_to_drop: list = []
) -> DataFrame:
    """Melt a dataframe, either passing a value_var list or removing columns from all the columns of the data frame to be passed as value_vars.

    Args:
        df (DataFrame): Spark data frame to be melted.
        id_vars (list): List of column names to be passed as ID in the melt.
        value_vars (list, optional): List of column names to be passed as value_vars in the melt. Defaults to an empty list.
        cols_to_drop (list, optional): List of column names to be removed from df.columns and passed as the value_vars argument. Defaults to an empty list.

    Returns:
        DataFrame: Melted data frame
    """
    if len(value_vars) == 0:
        value_vars = [x for x in df.columns if x not in cols_to_drop]
    melt_df = (
        df.to_pandas_on_spark().melt(id_vars=id_vars, value_vars=value_vars).to_spark()
    )

    return melt_df


def replace_value_to_null(df: DataFrame, cols: list = [], value: str = "") -> DataFrame:
    """Replace a specific string with Null/None in a dataframe, evaluating all columns or only a subset.

    Args:
        df (DataFrame): Spark data frame to be evaluated.
        cols (list, optional): List of columns to be evaluated. Defaults to empty list to evaluate all columns.
        value (str, optional): String to be replaced with null. Defaults to "".

    Returns:
        DataFrame: Data Frame with strings replaced.
    """
    if len(cols) == 0:
        cols = df.columns
    for c in cols:
        df = df.withColumn(c, F.when(F.col(c) == value, None).otherwise(F.col(c)))

    return df


def case_set_columns(df: DataFrame, cols: list = [], case: str = "lower") -> DataFrame:
    """Set a specific string case in a dataframe, evaluating all columns or only a subset.

    Args:
        df (DataFrame): Spark data frame to be evaluated.
        cols (list, optional): List of columns to be evaluated. Defaults to empty list to evaluate all columns.
        case (str, optional): String to select the string case: lower, upper or title. Defaults to "lower".

    Returns:
        DataFrame: Data Frame with strings cased.
    """
    case_dict = {"lower": F.lower, "upper": F.upper, "title": F.initcap}
    if len(cols) == 0:
        cols = df.columns
    for c in cols:
        df = df.withColumn(c, case_dict[case](F.col(c)))

    return df


def cross_tab(
    df: DataFrame,
    agg_func: any,
    col_to_pivot: str,
    cols_to_group: list = [],
    cols_to_drop: list = [],
) -> DataFrame:
    """Pivot a data frame, based in a col list to group or removing columns from all the columns of the data frame.

    Args:
        df (DataFrame): Data Frame to be pivoted
        agg_func (any): Pyspark function (F.something...) to be used in the aggregation.
        col_to_pivot (str): Column to be pivoted
        cols_to_group (list, optional): List of column names to be grouped in the pivot. Defaults to empty list.
        cols_to_drop (list, optional): List of column names to be removed from df.columns and passed as the cols_to_group argument (no need to include de col_to_pivot). Defaults to empty list.

    Returns:
        DataFrame: Pivoted Data Frame
    """
    if len(cols_to_group) == 0:
        cols_to_group = [
            x for x in df.columns if x not in (cols_to_drop + [col_to_pivot])
        ]
    df_pivot = df.groupBy(cols_to_group).pivot(col_to_pivot).agg(agg_func)

    return df_pivot


def left_join_with_residual_df(
    spark_session: SparkSession,
    left_df: DataFrame,
    other: DataFrame,
    df_dict_: dict,
    on: Any = None,
    how: str = "left",
    residual_type: str = "left",
    residual_alias: str = "residual_df",
    save_output: bool = True,
    groupby_col_names: list = [],
    debug_schema_name: str = "nps_prism_debug_layer",
) -> DataFrame:
    """Left join two data frames and add to df_dict the residual right dataframe using a defined alias.

    Args:
        left_df (DataFrame): Left Data Frame to join.
        other (DataFrame): Right Data Frame to join.
        df_dict_ (dict): Data frame dictionary of the yaml runner.
        on (Any, optional): A string for the join column name, a list of column names, a join expression (Column), or a list of Columns. Defaults to None.
        how (str, optional): Type of join to be made. Defaults to "left".
        residual_type: (str, optional): Type of anti-join to be made and saved as residual. Defaults to "left".
        residual_alias (str, optional): Alias of the residual right dataframe to be included in the df_dict. Defaults to "residual_df".
        save_output (bool, optional): Flag to define if the Data frame should be saved in the debug_layer. Defaults to True.
        groupby_col_names (list, optional): List of cols to group the residual data frame. Defaults to empty list.
        nps_prism_debug_layer (str, optional): Name of the debug schema created for the instrument. Defaults to "nps_prism_debug_layer"

    Returns:
        DataFrame: Left-Joined Data frame
    """
    df_joined = left_df.join(other, on=on, how=how)

    if residual_type == "left":
        df_dict_[residual_alias] = left_df.join(other, on=on, how="leftanti")
        if save_output == True:
            df_dict_[residual_alias] = (
                df_dict_[residual_alias]
                .groupBy(groupby_col_names)
                .agg(F.count("*").alias("count"))
            )
            df_to_delta_table(
                spark_session,
                df_dict_[residual_alias],
                debug_schema_name,
                residual_alias,
            )

    elif residual_type == "right":
        df_dict_[residual_alias] = other.join(left_df, on=on, how="leftanti")
        if save_output == True:
            df_dict_[residual_alias] = (
                df_dict_[residual_alias]
                .groupBy(groupby_col_names)
                .agg(F.count("*").alias("count"))
            )
            df_to_delta_table(
                spark_session,
                df_dict_[residual_alias],
                debug_schema_name,
                residual_alias,
            )

    else:
        print(
            f'Residual Type "{residual_type}" not found, please select between "left" or "right".'
        )

    return df_joined


def merge_and_update_dfs(
    spark_session: SparkSession,
    df_base: DataFrame,
    df_to_compare: DataFrame,
    col_name: str,
    bucket: str,
    path_to_csv: str,
    table: str,
    schema: str = "nps_prism_silver_layer",
) -> DataFrame:
    """Update values of columns 'ind_current_record' and 'effective_end_date' based on an inner join of two DataFrames, performed in the 'col_name' argument.
       The output DataFrame is saved to S3 in csv format.
    Args:
        df_base (DataFrame): Main DataFrame to be updated
        df_to_compare (DataFrame): DataFrame to be joined to attain the matched values
        col_name (str): Column in which the join is performed
        bucket (str): Bucket name where the csv file is stored
        path_to_csv (str): Path to which the csv file will be rewritten
        table (str): table to be updated. Ideally, it should be the same name as the 'df_base' table.
        schema (str): Schema in which the table to be updated is saved. Defaults to 'nps_prism_silver_layer'

    Returns:
        DataFrame: Updated DataFrame
    """

    df_final = df_base.join(df_to_compare, on=[col_name])

    list_of_vals = set([item[0] for item in df_final.select(col_name).collect()])

    df_base_1 = df_base.withColumn(
        "ind_current_record",
        F.when(F.col(col_name).isin(list_of_vals), F.lit(0)).otherwise(
            F.col("ind_current_record")
        ),
    )

    df_base_1 = df_base_1.withColumn(
        "effective_end_date",
        F.when(
            F.col(col_name).isin(list_of_vals), F.lit(F.current_timestamp())
        ).otherwise(F.col("effective_end_date")),
    )

    df_to_delta_table(spark_session, df_base_1, schema, table)

    df_to_s3_single_csv_file(df_base_1, bucket, path_to_csv, "overwrite")

    df_base_1_filtered = df_base_1.where(F.col(col_name).isin(list_of_vals))

    df_to_s3_single_csv_file(
        df_base_1_filtered, bucket, f"{path_to_csv}_filtered", "overwrite"
    )

    return df_base_1


def groupby_agg(
    df: DataFrame,
    cols_to_group: list,
    agg_functions: Any = None,
) -> DataFrame:
    """Group data frame by columns and apply aggregation functions

    Args:
        df (DataFrame): Data Frame to be grouped.
        cols_to_group (list): List of columns to group.
        agg_functions (Any, optional): Pyspark sql aggregation functions to be applied with alias. Defaults to None.

    Returns:
        DataFrame: Grouped Data frame.
    """
    if type(agg_functions) == tuple:
        df_grouped = df.groupBy(cols_to_group).agg(*agg_functions)
    else:
        df_grouped = df.groupBy(cols_to_group).agg(agg_functions)
    return df_grouped


def clean_duplicate_whitespace(
    df: DataFrame, cols_to_check: list = [], cols_to_drop: list = []
) -> DataFrame:
    """Clean multiple spaces to become a single space.

    Args:
        df (DataFrame): Data frame to be cleaned
        cols_to_check (list, optional): List of column names to be cleaned. Defaults to empty list.
        cols_to_drop (list, optional): List of column names to be removed from df.columns and passed as the cols_to_check argument.Defaults to empty list.

    Returns:
        DataFrame: Data frame with columns cleaned
    """
    if len(cols_to_check) == 0:
        cols_to_check = [x for x in df.columns if x not in cols_to_drop]
    for column in cols_to_check:
        df = df.withColumn(column, F.regexp_replace(F.col(column), "\s+", " "))

    return df


def update_columns(
    spark_session: SparkSession,
    df_base: DataFrame,
    value_to_update: str,
    col_name: str,
    bucket: str,
    path_to_csv: str,
    table: str,
    schema: str = "nps_prism_silver_layer",
    df_to_return: str = "updated",
) -> DataFrame:
    """Update values of columns 'ind_current_record' and 'effective_end_date' based on an inner join of two DataFrames, performed in the 'col_name' argument.
       The output DataFrame is saved to S3 in csv format.
    Args:
        spark_session (SparkSession): Spark Session of the cluster
        df_base (DataFrame): Main DataFrame to be updated
        value_to_update (str): value to be used to update the column
        col_name (col): column to be used for comparison based on 'value_to_update'
        bucket (str): Bucket name where the csv file is stored
        path_to_csv (str): Path to which the csv file will be rewritten
        table (str): table to be updated. Ideally, it should be the same name as the 'df_base' table.
        schema (str): Schema in which the table to be updated is saved. Defaults to 'nps_prism_silver_layer'
        df_to_return (str): to be inserted in case of which dataframe to be returned. Values should be 'updated', 'not updated', 'both'

    Returns:
        DataFrame: Updated DataFrame
    """

    df_final = df_base.join(df_to_compare, on=[col_name])

    list_of_vals = set([item[0] for item in df_final.select(col_name).collect()])

    df_base_1 = df_base.withColumn(
        "ind_current_record",
        F.when(F.col(col_name).isin([value_to_update]), F.lit(0)).otherwise(
            F.col("ind_current_record")
        ),
    )

    df_base_1 = df_base_1.withColumn(
        "effective_end_date",
        F.when(
            F.col(col_name).isin([value_to_update]), F.lit(F.current_timestamp())
        ).otherwise(F.col("effective_end_date")),
    )

    df_to_delta_table(spark_session, df_base_1, schema, table)

    df_to_s3_single_csv_file(df_base_1, bucket, path_to_csv, "overwrite")

    if df_to_return == "updated":
        df_base_1_filtered = df_base_1.where(F.col(col_name).isin([value_to_update]))

    elif df_to_return == "not updated":
        df_base_1_filtered = df_base_1.where(~F.col(col_name).isin([value_to_update]))

    elif df_to_return == "both":
        df_base_1_filtered = df_base_1
        path_to_csv = path_to_csv.split(".")[0] + "_updated.csv"

    df_to_s3_single_csv_file(df_base_1_filtered, bucket, f"{path_to_csv}", "overwrite")

    return df_base_1_filtered


def upsert_func(
    df_new: DataFrame,
    df_old: DataFrame,
    cols_to_compare: list,
    spark_session: SparkSession,
    schema: str,
    table_name: str,
) -> DataFrame:
    """Updates existing entries in a table and overwrite existing table in the defined layer.

    Args:
        df_new (DataFrame): Data Frame with new data
        df_old (DataFrame): Data frame of existing data
        cols_to_compare (list): Columns names list to be used as comparison
        spark_session (SparkSession): Spark Session name of the cluster
        schema (str): Schema in which the table to be updated is saved.
        table_name (str): Table to be updated. Ideally, it should be the same name as the 'df_old' table.

    Returns:
        DataFrame: Updated table
    """

    try:
        var_1 = delta_table_to_df(spark_session, schema, table_name)
        check_data = 0

    except:
        check_data = 1

    if check_data == 1:
        return df_old

    else:
        df_new_clean = df_new.select(cols_to_compare + ["hash_key"]).withColumnRenamed(
            "hash_key", "key_tgt_hash_new"
        )
        df_old_clean = df_old.select(
            cols_to_compare + ["key_tgt_hash"]
        ).withColumnRenamed("key_tgt_hash", "key_tgt_hash_old")

        df_joined = df_old_clean.join(df_new_clean, on=cols_to_compare, how="inner")
        df_joined = df_joined.withColumn(
            "to_update", F.col("key_tgt_hash_old") != F.col("key_tgt_hash_new")
        )

        # updating
        hashes_to_update = [
            x[0]
            for x in df_joined.where(
                (F.col("to_update") == "true") | (F.col("to_update") == True)
            )
            .select("key_tgt_hash_old")
            .collect()
        ]

        df_old_updated = (
            df_old.where(F.col("key_tgt_hash").isin(hashes_to_update))
            .withColumn("dte_eff_end", F.lit(F.date_sub(F.current_timestamp(), 1)))
            .withColumn("dte_update", F.lit(F.current_timestamp()))
            .withColumn("ind_current_record", F.lit(0))
            .withColumn(
                "gid_job_run",
                F.lit(df_new.select(F.max(df_new.gid_job_run)).collect()[0][0] + 1),
            )
        )

        # inserting
        df_old_not_updated = df_old.where(~F.col("key_tgt_hash").isin(hashes_to_update))

        df_old_complete = df_old_not_updated.union(df_old_updated)

        df_to_delta_table(spark_session, df_old_complete, schema, table_name)

        return df_old_complete


def drop_columns(df: DataFrame, cols_to_drop: list) -> DataFrame:
    """Drop columns from Data Frame based on a list of column names.

    Args:
        df (DataFrame): Data frame to have columns removed
        cols_to_drop (list): List of column names

    Returns:
        DataFrame: Data frame with columns removed
    """
    if type(cols_to_drop) == list:
        df_clean = df.drop(*cols_to_drop)
        return df_clean
    elif type(cols_to_drop) == str:
        df_clean = df.drop(cols_to_drop)
        return df_clean
    else:
        print("Typing of cols_to_drop is incorrect. Should be a list or a string.")
        return None


def col_name_df_creator(df: DataFrame, col_name: str) -> DataFrame:
    """Create a single column dataframe with the column names of a base dataframe

    Args:
        df (DataFrame): Base dataframe, which columns will be passed to the column
        col_name (str): Name of the column in the new DF

    Returns:
        DataFrame: Data frame with a single column
    """
    import pyspark.pandas as ps

    df_col = ps.DataFrame(df.columns, columns=[col_name])
    df_col_spark = df_col.to_spark()

    return df_col_spark


def col_using_select_expr(df: DataFrame, col_name: str, expr: str) -> DataFrame:
    """Create a new column using a F.expr function.

    Args:
        df (DataFrame): Data frame where the column will be added
        col_name (str): Name of the new column
        expr (str): SQL expression used to create the new column

    Returns:
        DataFrame: Data frame added of the new column
    """
    df_with_col = df.withColumn(col_name, F.expr(expr))

    return df_with_col


def create_index_column(
    df: DataFrame,
    index_col_name: str,
    start_value: int = 1,
) -> DataFrame:
    """Create an monotonically increasing index column, starting with 1

    Args:
        df (DataFrame): DataFrame in which the index column should be inserted
        index_col_name (str): Name of the newly created index column
        start_value (int): initial value to start increasing. Defaults to 1

    Returns:
        DataFrame: DataFrame with new index column
    """

    start_value = int(start_value)

    start_new = start_value - 1

    from pyspark.sql.window import Window as W

    df = df.withColumn("idx", F.monotonically_increasing_id())
    windowSpec = W.orderBy("idx")
    df = df.withColumn(index_col_name, F.row_number().over(windowSpec))
    df = df.withColumn(index_col_name, F.col(index_col_name) + start_new)
    df = df.drop("idx")

    return df


def fill_gid_minus_one(df):
    """replaces null values in gid columns with -1

    Args:
        df (DataFrame): DataFrame to be updated

    Returns:
        DataFrame: Updated DataFrame
    """

    gid_cols = [c for c in df.columns if c.startswith("gid")]
    df_new = df.select(
        [F.when(F.col(c).isNull(), -1).otherwise(F.col(c)).alias(c) for c in gid_cols]
        + [c for c in df.columns if not c.startswith("gid")]
    )
    df_new = df_new.select(df.columns)

    return df_new


def convert_to_spark_df(
    spark_session: SparkSession,
    df_pandas: DataFrame,
) -> DataFrame:
    """converts Spark Pandas DataFrame to Spark DataFrame

    Args:
        df (DataFrame): DataFrame to be converted

    Returns:
        DataFrame: converter DataFrame
    """

    df_spark = spark_session.createDataFrame(df_pandas)

    return df_spark


def cast_columns(df, col_data_types):
    """Cast columns in a PySpark DataFrame based on a dictionary containing column names and data types.

    Args:
        df (pyspark.sql.DataFrame): The PySpark DataFrame to cast columns on.
        col_data_types (dict): The dictionary containing column names as keys and data types as values.

    Returns:
        pyspark.sql.DataFrame: The PySpark DataFrame with the casted columns.
    """

    for col_name, data_type in col_data_types.items():
        list_of_types = [
            "integer",
            "long",
            "string",
            "double",
            "float",
            "boolean",
            "binary",
        ]

        if data_type == "datetime":
            df = df.withColumn(col_name, F.col(col_name).cast("timestamp"))

        elif data_type == "date":
            df = df.withColumn(col_name, F.to_date(F.col(col_name), "yyyy-MM-dd"))

        elif data_type in list_of_types:
            df = df.withColumn(col_name, F.col(col_name).cast(data_type))

        elif data_type.startswith("decimal"):
            precision, scale = (
                data_type.replace("decimal(", "").replace(")", "").split(",")
            )
            df = df.withColumn(
                col_name,
                F.col(col_name).cast("decimal({},{})".format(precision, scale)),
            )

        elif data_type.startswith("map"):
            key_type, value_type = (
                data_type.replace("map(", "").replace(")", "").split(",")
            )
            df = df.withColumn(
                col_name,
                F.col(col_name).cast("map<{},{}>".format(key_type, value_type)),
            )

        elif data_type.startswith("struct"):
            struct_fields = data_type.replace("struct(", "").replace(")", "").split(",")
            struct_type = StructType(
                [
                    StructField(sf.split(":")[0], eval(sf.split(":")[1]), True)
                    for sf in struct_fields
                ]
            )
            df = df.withColumn(col_name, F.col(col_name).cast(struct_type))

        elif data_type.startswith("array"):
            inner_type = data_type.replace("array(", "").replace(")", "")
            df = df.withColumn(
                col_name, F.col(col_name).cast("array<{}>".format(inner_type))
            )

        else:
            raise ValueError("Invalid data type: {}".format(data_type))

    return df


def update_old_records(
    spark_session: SparkSession,
    df: DataFrame,
    col_name: str,
    bucket: str,
    path_to_csv: str,
    gid_job_run: int,
    table: str,
    schema: str = "nps_prism_silver_layer",
) -> DataFrame:
    """Update old records using:
        ind_current_record = 0,
        dte_eff_end = current date -1,
        dte_update = current date

    Args:
    - spark_session (SparkSession): Spark Session name of the cluster
    - df (DataFrame): Data frame of existing data
    - col_name (str): Name of the column to be updated
    - bucket (str): Bucket name where the csv file is stored
    - path_to_csv (str): Path to which the csv file will be rewritten
    - gid_job_run:(int): Gid_job_run value which need to be updated
    - table (str): table to be updated. Ideally, it should be the same name as the 'df' table.
    - schema (str, optional): Schema in which the table to be updated is saved. Defaults to "nps_prism_silver_layer".

    Returns:
        DataFrame: Updated DataFrame
    """
    if df.count() == 0:
        return df

    spark_session.sql(
        "UPDATE "
        + schema
        + "."
        + table
        + " SET ind_current_record = 0, dte_eff_end = cast(DATEADD(day, -1, CAST(current_date AS date)) as date), dte_update = CURRENT_TIMESTAMP, gid_job_run = "
        + str(gid_job_run)
        + " WHERE "
        + col_name
        + " in ("
        + ",".join(
            [str(x) for x in df.select(col_name).rdd.flatMap(lambda x: x).collect()]
        )
        + ")"
    )
    df_return = spark_session.sql(
        "select * from "
        + schema
        + "."
        + table
        + " where "
        + col_name
        + " in ("
        + ",".join(
            [str(x) for x in df.select(col_name).rdd.flatMap(lambda x: x).collect()]
        )
        + ")"
    )

    df_to_s3_single_csv_file(df_return, bucket, f"{path_to_csv}", "overwrite")

    return df_return


def table_size_check(df: DataFrame) -> Any:
    """Counts the number of rows in a Spark DataFrame, returning an exception is the count is 0.

    Args:
        df (DataFrame): DataFrame to be evaluated

    Returns:
        DataFrame: Input DataFrame if row count is not 0
        Exception: Exception if row count is 0
    """

    if df.count() != 0:
        return df

    raise Exception("Dataframe is empty. YAML flow interrupted.")


def get_user_id(spark_session: SparkSession, df: DataFrame, col_name: str) -> DataFrame:
    """Returns column with the email os the session user

    Args:
        spark_session (SparkSession): Spark Session name of the cluster
        df (DataFrame): Data frame of existing data
        col_name (str): Name of the column to be updated

    Returns:
        DataFrame: Updated DataFrame
    """

    result = spark_session.sql("Select current_user()").collect()[0][0]

    df = df.withColumn(col_name, F.lit(result))

    return df


def regex_multi_replace(
    rule_dict: dict, srting_to_eval: str, only_first: str = False
) -> str:
    """Get a dictionary of values and patterns and replace these patterns in the string.

    Args:
        rule_dict (dict): dictionary of values and patterns to replace
        srting_to_eval (str): String to be evaluated
        only_first (str, optional): Replaces only the first match of pattern or all of them. Defaults to False.

    Returns:
        str: String with patterns replaced
    """
    key = sorted([i for i in rule_dict.keys()], key=len)[::-1]

    for item in set(re.findall(r"(" + "|".join(key) + ")", srting_to_eval)):
        if only_first:
            srting_to_eval = re.sub(
                r"(" + item + ")", rule_dict.get(item, ""), srting_to_eval, count=1
            )
            break
        srting_to_eval = re.sub(
            r"(" + item + ")", rule_dict.get(item, ""), srting_to_eval
        )

    return srting_to_eval


def find_and_replace(
    df_base: DataFrame,
    df_look: DataFrame,
    base_col: str,
    look_match_col: str,
    look_replace_col: str,
    how_match: str,
    only_first_match: str = False,
) -> DataFrame:
    """Relate two columns from different dataframes and replace patterns using a third column.

    Args:
        df_base (DataFrame): Data Frame with the column to be evaluated and have strings replaced
        df_look (DataFrame): Data Frame with the columns to relate with the first one and the pattern to replace the strings
        base_col (str): Column to be evaluated and have strings replaced
        look_match_col (str): Column to relate with the base_col
        look_replace_col (str): Column with the pattern to replace in the strings
        how_match (str): How to match base_col and look_match_col ->
            "begin" = base_col begins with look_match_col
            "any_part" = base_col contains look_match_col in any position
            "full_match" = base_col equals to look_match_col
        only_first_match (str, optional): Relevant only to how_match = any_part. Replaces only the first match of the look_match_col or all of them. Defaults to False.

    Returns:
        DataFrame: Data Frame with column replaced
    """

    df_look = df_look.select([look_match_col, look_replace_col])

    if (df_base.count() == 0) or (df_look.count() == 0):
        return df_base

    # Rename columns if the name is the same to drop at the end
    if base_col == look_match_col:
        df_look = df_look.whithColumnRenamed(
            look_match_col, f"{look_match_col}_look_df"
        )
        look_match_col = f"{look_match_col}_look_df"

    if how_match == "begin":
        sub_dict = {
            item[0]: item[1]
            for item in df_look.select(look_match_col, look_replace_col).collect()
        }
        sub_keys = [i for i in sub_dict.keys()]
        expr_k = r"^(" + "|".join(sub_keys) + ")"
        rdd_sub = df_base.select(base_col).rdd.map(
            lambda x: (
                x[0],
                re.sub(
                    expr_k,
                    sub_dict.get(
                        ""
                        if re.match(expr_k, x[0]) == None
                        else re.match(expr_k, x[0])[0],
                        "",
                    ),
                    x[0],
                ),
            )
        )

        df_sub = rdd_sub.toDF([base_col, "new_col"])
        df_replace = (
            df_base.join(df_sub, base_col)
            .drop(base_col)
            .withColumnRenamed("new_col", base_col)
        )

    elif how_match == "any_part":
        sub_dict = {
            item[0]: item[1]
            for item in df_look.select(look_match_col, look_replace_col).collect()
        }
        rdd_sub = df_base.select(base_col).rdd.map(
            lambda x: (x[0], regex_multi_replace(sub_dict, x[0], only_first_match))
        )

        df_sub = rdd_sub.toDF([base_col, "new_col"])
        df_replace = (
            df_base.join(df_sub, base_col)
            .drop(base_col)
            .withColumnRenamed("new_col", base_col)
        )

    elif how_match == "full_match":
        df_replace = df_base.join(
            df_look, df_base[base_col] == df_look[look_match_col], how="left"
        )
        df_replace = df_replace.withColumn(
            base_col, F.coalesce(F.col(look_replace_col), F.col(base_col))
        ).drop(look_match_col, look_replace_col)
    else:
        print("'how' parameter should be: begin, any_part or full_match")
        return df_base

    return df_replace


def update_job_details(
    spark_session: SparkSession,
    prefix: str,
    job_dtl: DataFrame,
    schema: str,
    final_table_count: int = 0,
    duplicates: int = None,
    rejected: int = None,
    last_gid: int = None,
    dup_comes_first: bool = True,
) -> DataFrame:
    """
    Update job details based on the given main_raw_data and optional gid_prefix.

    Args:
    - spark_session (SparkSession): Spark Session name of the cluster
    - prefix (str): prefix for the entry on abc table
    - job_dtl (DataFrame): DataFrame containing job details
    - schema (str): Schema for the abc_job_run table to be saved
    - final_table_count (int): Optional DataFrame to which the count is performed
    - duplicates (int): Optional duplicate records removed dataframe count
    - rejected (int): Optional rejected records removed dataframe count
    - last_gid (int): Optional max_gid value
    - dup_comes_first (bool): Optional boolean value which determines if duplicate count is calculated first or rejected count    
    
    Returns:
    - DataFrame: Updated job details DataFrame.
    """
    if dup_comes_first:
        job_dtl = job_dtl.withColumn(
            "Duplicates",
            F.lit((F.col("cnt_src_read") - duplicates) if duplicates else 0)
        ).withColumn(
            "Rejected",
            F.lit(
                (F.col("cnt_src_read") - F.col("Duplicates") - rejected)
                if rejected
                else 0
            ),
        )
    else:
        job_dtl = job_dtl.withColumn(
            "Rejected", F.lit((F.col("cnt_src_read") - rejected) if rejected else 0)
        ).withColumn(
            "Duplicates",
            F.col(
                (F.col("cnt_src_read") - F.col("Rejected") - duplicates)
                if duplicates
                else 0
            ),
        )

    job_dtl = job_dtl.withColumn("key_val_error", F.lit("Not Applicable"))

    job_dtl = (
        job_dtl.withColumn("cnt_tgt_read", F.lit(final_table_count))
        .withColumn("dte_job_end_time", F.current_timestamp())
        .withColumn("desc_job_status", F.lit("Completed"))
        .withColumn("cnt_tgt_error", F.lit(F.col("Duplicates") + F.col("Rejected")))
        .withColumn(
            "desc_error",
            F.expr(
                "case when cnt_tgt_error > 0 and Duplicates = 0 then 'Rejected' "
                + "when cnt_tgt_error > 0 and Duplicates > 0 then 'Rejected And Duplicate Error' "
                + "when cnt_tgt_error > 0 and Rejected = 0 then 'Duplicate Error' "
                + " else 'No error' end"
            ),
        )
    )

    job_dtl = job_dtl.withColumn("last_gid", F.lit(last_gid))

    job_dtl = cast_columns(
        job_dtl,
        {
            "gid_job": "integer",
            "cnt_src_read": "string",
            "cnt_tgt_read": "string",
            "cnt_tgt_error": "string",
            "last_gid": "string",
        },
    ).select(
        "gid_job",
        "gid_job_run",
        "desc_job_status",
        "dte_job_start_time",
        "id_usr_run",
        "cnt_src_read",
        "cnt_tgt_read",
        "cnt_tgt_error",
        "dte_job_end_time",
        "last_gid",
        "desc_error",
        "key_val_error",
    )

    update_and_load_abc_entry(spark_session, job_dtl, prefix, schema)

    return job_dtl


def abc_initial(
    spark_session: SparkSession,
    df: DataFrame,
    job_dtl: DataFrame,
    job_run_dtl: DataFrame,
    pipeline_name: str,
) -> DataFrame:
    """Initializes the job details dataframe with the first job run details and other default values.

    Args:
        spark_session: SparkSession object.
        df: DataFrame object representing the source data.
        job_dtl: DataFrame object representing the job details.
        job_run_dtl: DataFrame object representing the job run details.
        pipeline_name: String representing the name of the pipeline.

    Returns: DataFrame object representing the initialized job details."""

    job_dtl = job_dtl.select("gid_job", "nam_job")
    job_run_dtl = job_run_dtl.selectExpr("max(gid_job_run) as gid_job_run")

    abc_job_run_dtl = job_run_dtl.selectExpr(
        "coalesce(gid_job_run, 0) + 1 as gid_job_run",
        "current_timestamp() as dte_job_start_time",
        "'Started' as desc_job_status",
        f"'{pipeline_name}' as job_name",
    )

    abc_job_run_dtl = get_user_id(spark_session, abc_job_run_dtl, "id_usr_run")

    job_dtl = abc_job_run_dtl.join(
        job_dtl, abc_job_run_dtl.job_name == job_dtl.nam_job, how="left"
    ).select(
        "gid_job",
        "gid_job_run",
        "job_name",
        "dte_job_start_time",
        "desc_job_status",
        "id_usr_run",
    )

    job_dtl = job_dtl.withColumn(
        "gid_job", F.when(F.col("gid_job").isNull(), -2).otherwise(F.col("gid_job"))
    )

    job_dtl = job_dtl.withColumn("cnt_src_read", F.lit(df.count()))

    return job_dtl


def find_and_replace_new(
    df_base, df_look, base_col, look_match_col, look_replace_col, how_match
) -> DataFrame:
    """Initializes the job details dataframe with the first job run details and other default values.

    Args:
        df_base: Base DataFrame to have values replaced.
        df_look: DataFrame which has replacing values.
        base_col: Column to be compared on the base DataFrame
        look_match_col: column to be mattched on the DataFrame with the values to be replaced
        look_replace_col: col which contains replacing values
        how_maych: method in which the replace must be performed (begin, any_part, full_match)

    Returns: DataFrame with values replaced on the selected column
    """

    if (df_base.count() == 0) or (df_look.count() == 0):
        return df_base

    df_look = df_look.select([look_match_col, look_replace_col])

    if base_col == look_match_col:
        df_look = df_look.whithColumnRenamed(
            look_match_col, f"{look_match_col}_look_df"
        )
        look_match_col = f"{look_match_col}_look_df"

    if how_match == "begin":
        df_replace = df_base.join(
            df_look, df_base[base_col].startswith(df_look[look_match_col]), how="left"
        )

    elif how_match == "any_part":
        lkp_list = [row[look_match_col] for row in df_look.collect()]
        ret_list = [row[look_replace_col] for row in df_look.collect()]
        for i in range(len(lkp_list)):
            df_base = df_base.withColumn(
                base_col, F.regexp_replace(F.col(base_col), lkp_list[i], ret_list[i])
            )

        return df_base

    elif how_match == "full_match":
        df_replace = df_base.join(
            df_look, df_base[base_col] == df_look[look_match_col], how="left"
        )

    else:
        print("'how' parameter should be: begin, any_part or full_match")
        return df_base

    df_replace = df_replace.withColumn(
        base_col, F.coalesce(F.col(look_replace_col), F.col(base_col))
    ).drop(look_match_col, look_replace_col)

    return df_replace


def regex_adjust_cols(
    df: DataFrame, list_of_cols: list, dict_subs: dict = None
) -> DataFrame:
    """Replaces incorrect values in columns selected by the user

    Args:
        df (DataFrame): Base DataFrame to have values replaced.
        list_of_cols (list): List of columns in which the values should be treated.
        dict_subs: dictionary in which other values, set by the user, is added to the preexisting dict

    Returns: DataFrame with corrected values
    """

    dict_replace = {"‘": "'", "’": "'", "“": '"', "”": '"'}
    if dict_subs is not None:
        for key in dict_subs.keys():
            dict_replace[key] = dict_subs[key]

    for col in list_of_cols:
        for pattern, replacement in dict_replace.items():
            udf_replace = F.udf(
                lambda x: re.sub(pattern, replacement, str(x)), StringType()
            )
            df = df.withColumn(
                col,
                F.when(F.col(col).isNotNull(), F.trim(udf_replace(df[col]))).otherwise(
                    F.col(col)
                ),
            )

    return df


def eq_null_safe_join(
    df_base: DataFrame, 
    df_to_join: DataFrame, 
    list_of_cols: list, 
    join_type: str
    )-> DataFrame:

    """Performs a join between two DataFrames with the EqNullSafe condition satisfied

    Args:
        df_base: Base DataFrame to be joined.
        df_to_join: DataFrame to be joined.
        list_of_cols: list of columns in which the join should be performed
        join_type: Type of Join

    Returns: Joined DataFrame
    """

    from functools import reduce

    #setting columns to compare
    join_cols = list_of_cols
    if list_of_cols == None:
        join_cols = df_base.columns

    join_condition = reduce(lambda x, y: x & y, [df_base[k].eqNullSafe(df_to_join[k]) for k in join_cols])

    drop_condition = [df_base[k] for k in join_cols]

    df_final = df_base.join(df_to_join, on=join_condition, how=join_type).drop(*drop_condition)

    return df_final


def exclusion_mapping_df(
    spark_session: SparkSession, 
    df_exclusion: DataFrame, 
    fact_cols: list, 
    layer: str, 
    instrument: str
    )->DataFrame:

    """Builds the Ref Exclusion DataFrame to be joined to the Fact Response table

    Args:
        spark_session (SparkSession): The Spark Session of the notebook
        df_exclusion (DataFrame): Exclusion Vals DataFrame
        fact_cols (list): List of columns of the Fact Response DataFrame
        layer (str): Layer from which to read the Exclusion Vals file
        instrument (str): The instrument for the specific table

    Returns: Exclusion Vals DataFrame
    """

    df_exclusion = regex_adjust_cols(df_exclusion, df_exclusion.columns)

    list_of_cols = [item for item in df_exclusion.columns if 'field_name' in item]

    cols = [df_exclusion.select(list_of_cols).distinct().collect()[0][i] for i in range(len(list_of_cols))]

    dict_replace = {
        'Loop 1': 'provider',
        'Loop 2': 'product',
        'Loop 3': 'episode',
        'Loop 4': 'channel'
    }   

    cols_adjusted = [item.lower() if item not in dict_replace.keys() else dict_replace[item] for item in cols]

    list_of_field_vals = [item for item in df_exclusion.columns if 'field_value' in item]

    df_exc_vals = df_exclusion.select(list_of_field_vals)

    dict_to_rename = dict(zip(list_of_field_vals, cols_adjusted))

    df_exc_vals = rename_multiple_columns(df_exc_vals, dict_to_rename)

    # list of cols to remap with gid
    list_of_cols_to_remap = [item for item in cols_adjusted if item in [item.split("gid_")[-1] for item in fact_cols if 'gid_' in item]] 

    dict_dfs = {}

    for item in list_of_cols_to_remap:

        dict_dfs[item] = delta_table_to_df(spark_session, layer, f'{instrument}_dim_{item}')

        list_cols_select = [col for col in dict_dfs[item].columns if (f'gid_{item}' in col or f'nam_{item}' in col) and (len(col.split("_")) == 2)]

        if item == 'respondent':
            
            list_cols_select = list_cols_select + ['respondent']

        print(list_cols_select)

        dict_dfs[item] = dict_dfs[item].select(list_cols_select)
        
        # print(f'{[item for item in list_cols_select if "gid" not in item]}', item)

        dict_dfs[item] = dict_dfs[item].withColumnRenamed(f'{[item for item in list_cols_select if "gid" not in item][0]}', item)

        df_exc_vals = df_exc_vals.join(dict_dfs[item], on=item, how='left')
        
        df_exc_vals = df_exc_vals.na.fill(-1, subset=['gid_'+item])

    df_exc_vals = df_exc_vals.drop(*list_of_cols_to_remap).withColumn('flag_xref_vals', F.lit(1))

    return df_exc_vals