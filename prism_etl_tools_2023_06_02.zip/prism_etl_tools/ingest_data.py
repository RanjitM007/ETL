from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import SparkSession
from pyspark.sql.dataframe import DataFrame
from botocore import client
import boto3


def s3_csv_to_df(
    spark_session: SparkSession,
    bucket: str,
    path: str,
    lib: str = 'pyspark',
    aws_key: str = '',
    aws_secret: str = '',
    sep: str = ",",
    header: str = "true",
    **kwargs,
) -> DataFrame:
    """Read a csv flat file from S3 bucket in AWS and ingests it as a Pyspark Dataframe.

    Args:
        spark_session (SparkSession): Spark Session of the cluster
        bucket (str): Bucket name to be read from in S3
        path (str): Path to file, inside bucket
        lib (str): which library should perform the read function.  Either 'pyspark', 'polars' or 'pandas'.
        aws_key (str, optional): AWS User Access Key.
        aws_secret (str, optional): AWS User Secret Key.
        sep (list, optional): Sets a separator for each field and value. Defalts to ','
        header (str, optional): For reading, uses the first line as names of columns. Defalts to 'true'
        kwarg (Any): Any other options (key, value pair) from the spark.read.csv function. Format to be used 'key'='value'

    Returns:
        spark.DataFrame: Spark dataframe created using the csv file
    """
    
    if lib == 'pandas':
        
        import boto3
        import pandas as pd
        
        s3_client = boto3.client('s3', aws_access_key_id=aws_key, aws_secret_access_key=aws_secret)
        response = s3_client.get_object(Bucket=bucket, Key=path)
        df = pd.read_csv(response.get("Body"))                           
        df_spark = spark_session.createDataFrame(df)
        
        return df_spark
    
    else:
        df = spark_session.read.options(sep=sep, header=header, **kwargs).csv(
            f"s3://{bucket}/{path}"
        )
        
        return df


def delta_table_select_to_df(
    spark_session: SparkSession, schema: str, table_name: str, limit_exp: str = ""
) -> DataFrame:
    """Query a delta table with a limit expression and ingests it as a Pyspark Dataframe.

    Args:
        spark_session (SparkSession): Spark Session of the cluster
        schema (str): Schema where the data table resides
        table_name (str): Name of the table to be read
        limit_expr (str, optional): SQL like clause to limit the number of rows read. Format to be used 'limit <number of rows>'. Defalts to empty string (all rows)

    Returns:
        spark.DataFrame: Spark dataframe created reading the delta table
    """
    df = spark_session.sql(f"select * from {schema}.{table_name} {limit_exp}")
    return df


def delta_table_to_df(
    spark_session: SparkSession, schema: str, table_name: str
) -> DataFrame:
    """Read a whole delta table and ingests it as a Pyspark Dataframe.

    Args:
        spark_session ()
        schema (str): Schema where the data table resides
        table_name (str): Name of the table to be read

    Returns:
        spark.DataFrame: Spark dataframe created reading the delta table
    """
    df = spark_session.table(f"{schema}.{table_name}")
    return df

def s3_file_to_binary(
    bucket: str,
    path: str,
    file_data_type: str,
    aws_key: str = '',
    aws_secret: str = '',
    **kwargs,
):
    """Read a xlsx file from S3 bucket in AWS and ingests it as a Pyspark Dataframe.

    Args:
        bucket (str): Bucket name to be read from in S3
        path (str): Path to file, inside bucket
        file_data_type (str): The type of file the user is ingesting.
        aws_key (str, optional): AWS User Access Key.
        aws_secret (str, optional): AWS User Secret Key.
        sep (list, optional): Sets a separator for each field and value. Defalts to ','
        kwarg (Any): Any other options (key, value pair) from the spark.read.csv function. Format to be used 'key'='value'

    Returns:
        spark.DataFrame: Spark dataframe created using the xlsx file
    """
    
    list_of_data_types = ['taxonomy', 'variable_mapping', 'answer_key', 'exclusion_vals', 'question']

    if file_data_type not in list_of_data_types:
        raise BaseException(f"Wrong type data file type. Expecting {', '.join(list_of_data_types)}.")

    import boto3
    import pandas as pd
    import io

    session = boto3.Session(aws_access_key_id=aws_key, aws_secret_access_key=aws_secret)
    s3 = session.resource('s3')
    my_bucket = s3.Bucket(bucket)

    list_of_files = []

    for my_bucket_object in my_bucket.objects.filter(Prefix=path):
        if file_data_type in my_bucket_object.key.replace(" ", "_").lower():
            list_of_files.append(my_bucket_object.key)

    if len(list_of_files) > 1:
        raise BaseException(f"More than one {file_data_type} found in the bucket. Please make sure only the correct file is the folder.")

    obj = my_bucket.Object(list_of_files[0]).get()
    data = io.BytesIO(obj['Body'].read())

    return data

def s3_get_file_name(
    bucket: str,
    path: str,
    aws_key: str = '',
    aws_secret: str = '',
    **kwargs,
)-> list:
    """Returns a list of files in a S3 bucket

    Args:
        bucket (str): Bucket name to be read from in S3
        path (str): Path to file, inside bucket
        aws_key (str, optional): AWS User Access Key.
        aws_secret (str, optional): AWS User Secret Key.
        kwarg (Any): Any other options (key, value pair) from the spark.read.csv function. Format to be used 'key'='value'

    Returns:
        list: list of files within S3 bucket
    """

    import boto3

    session = boto3.Session(aws_access_key_id=aws_key, aws_secret_access_key=aws_secret)
    s3 = session.resource('s3')
    my_bucket = s3.Bucket(bucket)

    list_of_files = []

    for my_bucket_object in my_bucket.objects.filter(Prefix=path):
        list_of_files.append(my_bucket_object.key)

    return list_of_files


def recoding_adjustment_tables(
        spark_session: SparkSession,
        df_rules: DataFrame,
        first_row_adj:int = 0
        )->dict:
    """Returns a dictionary with all tables in the 'Rules' tab of the Variable Mapping file as PySpark DataFrames

    Args:
        spark_session (SparkSession): Spark Session of the cluster
        df_rules (DataFrame): DataFrame of the 'Rules' tab of the Variable Mapping file
        first_row_adj (int): numbers of rows to skip

    Returns:
        dict: Dictionary with all tables in the 'Rules' tab of the Variable Mapping file as PySpark DataFrames
    """
    dict_dfs = {}

    # question mapping

    cols = [item.lower() for item in df_rules.iloc[first_row_adj, :4].tolist()]
    df_rules_question_mapping = df_rules.iloc[first_row_adj+1:, :4].dropna(how='all')
    df_rules_question_mapping.columns = cols

    dict_dfs['ans_text_mapping'] = spark_session.createDataFrame(df_rules_question_mapping)

    for col in dict_dfs['ans_text_mapping'].columns:
        dict_dfs['ans_text_mapping'] = dict_dfs['ans_text_mapping'].withColumn(col, F.when(F.col(col) == 'NaN', None).otherwise(F.col(col)))


    # question recoding

    cols = [item.lower() for item in df_rules.iloc[first_row_adj+1, 5:7].tolist()]
    df_rules_question_recoding = df_rules.iloc[first_row_adj+2:, 5:7].dropna(how='all')
    df_rules_question_recoding.columns = cols

    dict_dfs['question_recoding'] = spark_session.createDataFrame(df_rules_question_recoding)


    # awswer recoding

    cols = [item.lower() for item in df_rules.iloc[first_row_adj+1, 8:10].tolist()]
    df_rules_answer_recoding = df_rules.iloc[first_row_adj+2:, 8:10].dropna(how='all')
    df_rules_answer_recoding.columns = cols

    df_rules_answer_recoding['text'] = df_rules_answer_recoding['text'].apply(lambda x: x.replace("'", "") if x.startswith("'") else x)
    df_rules_answer_recoding['recoded_text'] = df_rules_answer_recoding['recoded_text'].astype('str')

    dict_dfs['recoding_ans_txt'] = spark_session.createDataFrame(df_rules_answer_recoding)
    dict_dfs['recoding_ans_txt'] = dict_dfs['recoding_ans_txt'].withColumn('text', F.trim(F.col('text')))
    dict_dfs['recoding_ans_txt'] = dict_dfs['recoding_ans_txt'].distinct()


    # answer_recoding num

    cols = [item.lower() for item in df_rules.iloc[first_row_adj+1, 11:13].tolist()]
    df_rules_answer_num_recoding = df_rules.iloc[first_row_adj+2:, 11:13].dropna(how='all')
    df_rules_answer_num_recoding.columns = cols

    dict_dfs['recoding_ans_num'] = spark_session.createDataFrame(df_rules_answer_num_recoding)
    dict_dfs['recoding_ans_num'] = dict_dfs['recoding_ans_num'].withColumn('text', F.trim(F.col('text')))
    dict_dfs['recoding_ans_num'] = dict_dfs['recoding_ans_num'].distinct()


    # open ended questions

    cols = [item.lower() for item in df_rules.iloc[first_row_adj+1, 14:16].tolist()]
    df_rules_open_ended_questions = df_rules.iloc[first_row_adj+2:, 14:16].dropna(how='all')
    df_rules_open_ended_questions.columns = cols
    df_rules_open_ended_questions = df_rules_open_ended_questions.dropna(subset=[item for item in df_rules_open_ended_questions.columns if 'question' not in item])

    dict_dfs['open_ended_questions'] = spark_session.createDataFrame(df_rules_open_ended_questions)


    # epdd color mapping

    cols = [item.lower() for item in df_rules.iloc[first_row_adj+1, 17:20].tolist()]
    df_rules_epdd_color_mapping = df_rules.iloc[first_row_adj+2:, 17:20].dropna(how='all')
    df_rules_epdd_color_mapping.columns = cols

    dict_dfs['epdd_color_mapping'] = spark_session.createDataFrame(df_rules_epdd_color_mapping)


    # special characters handling

    cols = [item.lower() for item in df_rules.iloc[first_row_adj+1, 21:23].tolist()]
    df_rules_special_chars = df_rules.iloc[first_row_adj+2:, 21:23].dropna(how='all')
    df_rules_special_chars.columns = cols

    dict_dfs['special_chars'] = spark_session.createDataFrame(df_rules_special_chars)
    
    return dict_dfs